<?php
$servername = "localhost";
$database = "project";
$username = "root";
$password = "";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database); ?>

